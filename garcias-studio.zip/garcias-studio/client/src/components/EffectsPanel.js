// Panel for audio effects (reverb, echo)
import React from 'react';

const EffectsPanel = () => {
  return <div>Effects Panel (TODO)</div>;
};

export default EffectsPanel;