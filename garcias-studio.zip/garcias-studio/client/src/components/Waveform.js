// Visualizes waveform using canvas
import React from 'react';

const Waveform = () => {
  return <div>Waveform Visualizer (TODO)</div>;
};

export default Waveform;